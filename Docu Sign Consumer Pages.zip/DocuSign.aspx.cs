﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DocuSign : System.Web.UI.Page
{
    private const string BaseURL = "https://account-d.docusign.com/oauth/auth?";
    //Client ID is available as Integration key on https://admindemo.docusign.com/api-integrator-key
    private const string ClientID = "b2396e85-d94c-46f7-88b4-df662181f6ee";
    // Below is the Redirect URL that reads Code attribute from docu sign step 1 auth.
    private const string encodedURL = "http%3A%2F%2Flocalhost%3A57784%2FDocuSignCallBack.aspx";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnStart_Click(object sender, EventArgs e)
    {

    }

    protected void btnStart_Click1(object sender, EventArgs e)
    {
        string authURL = $"{BaseURL}client_id={ClientID}&scope=signature&response_type=code&redirect_uri={encodedURL}";
        Response.Redirect(authURL);
    }
}