﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Script.Serialization;

public partial class DocuSignCallBack : System.Web.UI.Page
{
    // Account ID is available on https://admindemo.docusign.com/api-integrator-key
    private string accountID = "1a1108f3-77cd-444f-9a42-24ddcf6b50dc";
    protected async void Page_Load(object sender, EventArgs e)
    {
        string code = Request.QueryString["Code"];
        string tokenURL = "https://account-d.docusign.com/";

        using (var client = new HttpClient())
        {
            client.BaseAddress = new Uri(tokenURL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            // From Below content after Basic is generated as binary of string ('{clientid : SecretKey}'). Easy way to do is from Chrome console btoa('{clientid : SecretKey}')
            // Secret Key is found after we click in App name and edit app details.
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + "YjIzOTZlODUtZDk0Yy00NmY3LTg4YjQtZGY2NjIxODFmNmVlOjc1YWEyMmI1LTJiNzgtNDBhMC05NjhmLTI3NjFjMzkzZjM1NA==");
            Dictionary<string, string> postParams = new Dictionary<string, string>();
            postParams.Add("grant_type", "authorization_code");
            postParams.Add("code", code);
             
            HttpResponseMessage response = await client.PostAsync("oauth/token", new FormUrlEncodedContent(postParams));
            if (response.IsSuccessStatusCode)
            {
                string jsonResponse = await response.Content.ReadAsStringAsync();
                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                AuthResponse authResult =  json_serializer.Deserialize<AuthResponse>(jsonResponse);
                GetDataFromCore(authResult.access_token);
            }
            else
            {
                Console.WriteLine("Internal server Error");
            }
        }

    }

    private async void GetDataFromCore(string accesstoken)
    {
        string coreURL = "https://localhost:44333/";

        using (var client = new HttpClient())
        {
            client.BaseAddress = new Uri(coreURL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            Dictionary<string, string> postParams = new Dictionary<string, string>();
            postParams.Add("signerEmail", "test signer name");
            postParams.Add("signerName", "test signer name");
            postParams.Add("accessToken", accesstoken);
            postParams.Add("accountId", accountID);

            HttpResponseMessage response = await client.PostAsync("eg003", new FormUrlEncodedContent(postParams));
            if (response.IsSuccessStatusCode)
            {
                string jsonResponse = await response.Content.ReadAsStringAsync();
                lblresponse.Text = jsonResponse;

            }
            else
            {
                Console.WriteLine("Internal server Error");
            }
        }
    }
}

public class AuthResponse
{
    public string access_token { get; set; }

    public string token_type { get; set; }

    public string refresh_token { get; set; }

    public int expires_in { get; set; }
}